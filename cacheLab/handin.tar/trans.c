/* 202055516 Kim Myeongseo */ 
/* 
 * trans.c - Matrix transpose B = A^T
 *
 * Each transpose function must have a prototype of the form:
 * void trans(int M, int N, int A[N][M], int B[M][N]);
 *
 * A transpose function is evaluated by counting the number of misses
 * on a 1KB direct mapped cache with a block size of 32 bytes.
 */ 
#include <stdio.h>
#include "cachelab.h"

int is_transpose(int M, int N, int A[N][M], int B[M][N]);

/* 
 * transpose_submit - This is the solution transpose function that you
 *     will be graded on for Part B of the assignment. Do not change
 *     the description string "Transpose submission", as the driver
 *     searches for that string to identify the transpose function to
 *     be graded. 
 */
char transpose_submit_desc[] = "Transpose submission";
void transpose_submit(int M, int N, int A[N][M], int B[M][N])
{
	int rows, cols, k;
	int tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8;
	if(M==32 && N==32)
	{
		for (rows=0; rows<N; rows+=8)
		{
			for (cols=0; cols<M; cols +=8)
			{
				for (k=rows; k<rows+8; k++)
				{
					tmp1 = A[k][cols];
					tmp2 = A[k][cols+1];
					tmp3 = A[k][cols+2];
					tmp4 = A[k][cols+3];
					tmp5 = A[k][cols+4];
					tmp6 = A[k][cols+5];
					tmp7 = A[k][cols+6];
					tmp8 = A[k][cols+7];
					
					B[cols][k] = tmp1;
					B[cols+1][k] = tmp2;
					B[cols+2][k] = tmp3;
					B[cols+3][k] = tmp4;
					B[cols+4][k] = tmp5;
					B[cols+5][k] = tmp6;
					B[cols+6][k] = tmp7;
					B[cols+7][k] = tmp8;
				}
			}
		}
	}
	else if(M==64)
	{
		for(rows=0; rows<N; rows+=8)
		{
			for(cols=0; cols<M; cols+=8)
			{
				for(k=rows; k< rows+8; k++)
				{
					tmp1 = A[k][cols];
					tmp2 = A[k][cols+1];
					tmp3 = A[k][cols+2];
					tmp4 = A[k][cols+3];
					B[cols][k] = tmp1;
					B[cols+1][k] = tmp2;
					B[cols+2][k] = tmp3;
					B[cols+3][k] = tmp4;
				}
				for(k=rows; k<rows+8; k++)
				{
					tmp5 = A[k][cols+4];
					tmp6 = A[k][cols+5];
					tmp7 = A[k][cols+6];
					tmp8 = A[k][cols+7];
					B[cols+4][k] = tmp5;
					B[cols+5][k] = tmp6;
					B[cols+6][k] = tmp7;
					B[cols+7][k] = tmp8;
				}
			}
		}
	}
	else
	{
		int diagonal=0, index;
		for(rows=0; rows<N; rows+= 16)
		{
			for(cols=0; cols<M; cols+=16)
			{
				for(k=rows; (k<rows+16)&&(k<N); k++)
				{
					for(int l=cols; (l<cols+16)&&(l<M); l++)
					{
						if(k!=l)
							B[l][k] = A[k][l];
						else
						{
							tmp1 = A[k][l];
							index = k;
							diagonal =1;
						}
						if(diagonal)
						{
							B[index][index] = tmp1;
							diagonal=0;
						}
					}
				}
			}
		}
	}

}

char transpose_test_desc[] = "Test submission";
void transpose_test(int M, int N, int A[N][M], int B[M][N])
{
	int size, tmp, index;
	int rowBlock, colBlock, row, col;
	if(M == 32) 
		size = 8;
	else if (M==64)
		size = 4;
	else 
		size = 16;

	int diagonal =0;

	if(M==32||M==64)
	{
		for(rowBlock=0; rowBlock<N; rowBlock +=size)
		{
			for(colBlock=0; colBlock<M; colBlock+=size)
			{
				for(row=rowBlock; row<rowBlock+size;row++)
				{
					for(col=colBlock; col<colBlock+size;col++)
					{
						if(row!=col)
							B[col][row] = A[row][col];
						else
						{
							tmp = A[row][col];
							index = row;
							diagonal =1;
						}
					}
					if(diagonal)
					{
						B[index][index] = tmp;
						diagonal =0;
					}
				}
			}
		}
	}
	else
	{
		for(rowBlock=0; rowBlock<N; rowBlock+=size)
		{
			for(colBlock=0; colBlock<N; colBlock+=size)
			{
				for(row=rowBlock;(row<rowBlock+size)&&(row<N); row++)
				{
					for(col=colBlock;(col<colBlock+size)&&(col<M); col++)
					{
						if(row!=col)
							B[col][row] = A[row][col];
						else
						{
							tmp = A[row][col];
							index = row;
							diagonal =1;
						}
					}
					if(diagonal)
					{
						B[index][index] = tmp;
						diagonal=0;
					}
				}
			}
		}
	}
}


/* 
 * You can define additional transpose functions below. We've defined
 * a simple one below to help you get started. 
 */ 

/* 
 * trans - A simple baseline transpose function, not optimized for the cache.
 */
char trans_desc[] = "Simple row-wise scan transpose";
void trans(int M, int N, int A[N][M], int B[M][N])
{
    int i, j, tmp;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; j++) {
            tmp = A[i][j];
            B[j][i] = tmp;
        }
    }    

}

/*
 * registerFunctions - This function registers your transpose
 *     functions with the driver.  At runtime, the driver will
 *     evaluate each of the registered functions and summarize their
 *     performance. This is a handy way to experiment with different
 *     transpose strategies.
 */
void registerFunctions()
{
    /* Register your solution function */
    registerTransFunction(transpose_submit, transpose_submit_desc);
    registerTransFunction(transpose_test, transpose_test_desc); 

    /* Register any additional transpose functions */
    registerTransFunction(trans, trans_desc); 

}

/* 
 * is_transpose - This helper function checks if B is the transpose of
 *     A. You can check the correctness of your transpose by calling
 *     it before returning from the transpose function.
 */
int is_transpose(int M, int N, int A[N][M], int B[M][N])
{
    int i, j;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; ++j) {
            if (A[i][j] != B[j][i]) {
                return 0;
            }
        }
    }
    return 1;
}

